package com.anur.vcardpro.model

data class LoginResponse(
    val message: String,
    val user: User
)
