package com.anur.vcardpro.model

data class VisitorContactData(
    val name: String?,
    val email: String?,
    val phone: String?,
    val company: String?,
    val linkedin: String?
)
